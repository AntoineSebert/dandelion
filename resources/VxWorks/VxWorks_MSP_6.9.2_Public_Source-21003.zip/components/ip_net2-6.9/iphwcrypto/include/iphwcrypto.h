/* iphwcrypto.h - public API of cyptographic hardware support for Wind River Cryptography Libraries
*
*/
/*
 ******************************************************************************
 *                     INTERPEAK API HEADER FILE
 *
 *   Document no: @(#) $Name: release6_9_2_binmsp $ $RCSfile: iphwcrypto.h,v $ $Revision: 1.31 $
 *   $Source: /home/interpeak/CVSRoot/iphwcrypto/include/iphwcrypto.h,v $
 *   $Author: markus $ $Date: 2009-08-26 08:29:15 $
 *   $State: Exp $ $Locker:  $
 *
 *   INTERPEAK_COPYRIGHT_STRING
 *   Design and implementation by Markus Carlstedt <markus@interpeak.se>
 ******************************************************************************
 */
#ifndef IPHWCRYPTO_H
#define IPHWCRYPTO_H

/*
 ****************************************************************************
 * 1                    DESCRIPTION
 ****************************************************************************
 */
 /*
DESCRIPTION
This library contains the API for cryptographic hardware support for Wind River
* Cryptographic Libraries.
*/

/*
 ****************************************************************************
 * 2                    CONFIGURATION
 ****************************************************************************
 */

#include "iphwcrypto_config.h"


/*
 ****************************************************************************
 * 3                    INCLUDE FILES
 ****************************************************************************
 */

#include <ipcom_type.h>
#include <ipcom_cstyle.h>

#ifdef IPIPSEC2
#include <ipipsec.h>
#include <ipipsec_pfkeyv2.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif


/*
 ****************************************************************************
 * 4                    DEFINES
 ****************************************************************************
 */

/*
 *===========================================================================
 *                         IPHWCRYPTO_RELEASE
 *===========================================================================
 * IPHWCRYPTO release version.
 */
#define IPHWCRYPTO_RELEASE 60701


/*
 *===========================================================================
 *                  IPHWCRYPTO_ENGINE_DIGEST_...
 *===========================================================================
 * Identifiers for digest algorithm types. Use them to specify a digest type
 * when calling the iphwcrypto_engine_add_digest() function.
 *
 */
#define IPHWCRYPTO_ENGINE_DIGEST_MD5            0
#define IPHWCRYPTO_ENGINE_DIGEST_SHA1           1
#define IPHWCRYPTO_ENGINE_DIGEST_SHA1_DSA       2
#define IPHWCRYPTO_ENGINE_DIGEST_MAX            3   /* don't use */


/*
 *===========================================================================
 *                  IPHWCRYPTO_ENGINE_CIPHER_...
 *===========================================================================
 * Identifiers for cipher algorithm types. Use them to specify a cipher type
 * when calling the iphwcrypto_engine_add_cbc_cipher() and
 * iphwcrypto_engine_add_ecb_cipher() functions.
 *
 */
#define IPHWCRYPTO_ENGINE_CIPHER_DES_CBC        0
#define IPHWCRYPTO_ENGINE_CIPHER_DES_ECB        1
#define IPHWCRYPTO_ENGINE_CIPHER_3DES_CBC       2
#define IPHWCRYPTO_ENGINE_CIPHER_3DES_ECB       3
#define IPHWCRYPTO_ENGINE_CIPHER_AES128_CBC     4
#define IPHWCRYPTO_ENGINE_CIPHER_AES128_ECB     5
#define IPHWCRYPTO_ENGINE_CIPHER_AES192_CBC     6
#define IPHWCRYPTO_ENGINE_CIPHER_AES192_ECB     7
#define IPHWCRYPTO_ENGINE_CIPHER_AES256_CBC     8
#define IPHWCRYPTO_ENGINE_CIPHER_AES256_ECB     9
#define IPHWCRYPTO_ENGINE_CIPHER_MAX            10  /* don't use */


/*
 *===========================================================================
 *                  IPHWCRYPTO_ENGINE_ESP_...
 *===========================================================================
 * Identifiers for ipsec esp algorithm types. Use them to specify an esp type
 * when calling the iphwcrypto_ipsec_engine_add_esp() function.
 */
#define IPHWCRYPTO_ENGINE_ESP_NULL_NULL          0
#define IPHWCRYPTO_ENGINE_ESP_NULL_MD5           1
#define IPHWCRYPTO_ENGINE_ESP_NULL_SHA1          2
#define IPHWCRYPTO_ENGINE_ESP_DES_CBC_NULL       3
#define IPHWCRYPTO_ENGINE_ESP_DES_CBC_MD5        4
#define IPHWCRYPTO_ENGINE_ESP_DES_CBC_SHA1       5
#define IPHWCRYPTO_ENGINE_ESP_3DES_CBC_NULL      6
#define IPHWCRYPTO_ENGINE_ESP_3DES_CBC_MD5       7
#define IPHWCRYPTO_ENGINE_ESP_3DES_CBC_SHA1      8
#define IPHWCRYPTO_ENGINE_ESP_AES_CBC_NULL       9
#define IPHWCRYPTO_ENGINE_ESP_AES_CBC_MD5        10
#define IPHWCRYPTO_ENGINE_ESP_AES_CBC_SHA1       11
#define IPHWCRYPTO_ENGINE_ESP_CAST_CBC_NULL      12
#define IPHWCRYPTO_ENGINE_ESP_CAST_CBC_MD5       13
#define IPHWCRYPTO_ENGINE_ESP_CAST_CBC_SHA1      14
#define IPHWCRYPTO_ENGINE_ESP_BLF_CBC_NULL       15
#define IPHWCRYPTO_ENGINE_ESP_BLF_CBC_MD5        16
#define IPHWCRYPTO_ENGINE_ESP_BLF_CBC_SHA1       17
#define IPHWCRYPTO_ENGINE_ESP_MAX                18    /* don't use */

/* Maximum length of ipsec esp authentication key */
#define IPHWCRYPTO_ENGINE_ESP_MAX_AUTHKEY               20  /* SHA1 */

/* Maximum length of ipsec esp encryption key */
#define IPHWCRYPTO_ENGINE_ESP_MAX_ENCKEY                32  /* AES256 */


/*
 ****************************************************************************
 * 5                    TYPES
 ****************************************************************************
 */

/*
 *===========================================================================
 *                  Iphwcrypto_digest_init
 *===========================================================================
 * Description: Function pointer type for message digest context initialization.
 * Parameters:  ctx - Pointer to the message digest context. The size of the
 *                    context is specified in the call to iphwcrypto_engine_add_digest().
 * Returns:     -1 = error
 *               0 = timeout
 *               1 = ok
 *
 */
typedef int (* Iphwcrypto_digest_init) (void *ctx);


/*
 *===========================================================================
 *                  Iphwcrypto_digest_update
 *===========================================================================
 * Description: Function pointer type for message digest update.
 * Parameters:  ctx   - pointer to the message digest context.
 *              data  - pointer to the data to hash.
 *              count - the number of bytes of data to hash.
 * Returns:     -1 = error
 *               0 = timeout
 *               1 = ok
 *
 */
typedef int (* Iphwcrypto_digest_update) (void *ctx, IP_CONST Ip_u8 *data, Ip_u32 length);


/*
 *===========================================================================
 *                  Iphwcrypto_digest_final
 *===========================================================================
 * Description: Function pointer type for message digest final stage.
 * Parameters:  ctx - pointer to the message digest context.
 *              md  - pointer to buffer with the message digest.
 * Returns:     -1 = error
 *               0 = timeout
 *               1 = ok
 */
typedef int (* Iphwcrypto_digest_final) (void *ctx, Ip_u8 *md);


/*
 *===========================================================================
 *                  Iphwcrypto_digest_copy
 *===========================================================================
 * Description: Function pointer type for message digest copy.
 * Parameters:  ctx_to   - pointer to the destination message digest context.
 *              ctx_from - pointer to the source message digest context.
 * Returns:     -1 = error
 *               0 = timeout
 *               1 = ok
 */
typedef int (* Iphwcrypto_digest_copy) (void *ctx_to, IP_CONST void *ctx_from);


/*
 *===========================================================================
 *                  Iphwcrypto_digest_cleanup
 *===========================================================================
 * Description: Function pointer type for message digest cleanup.
 * Parameters:  ctx  - pointer to the message digest context.
 * Returns:     -1 = error
 *               0 = timeout
 *               1 = ok
 */
typedef int (* Iphwcrypto_digest_cleanup) (void *ctx);


/*
 *===========================================================================
 *                  Iphwcrypto_cbc_cipher_calc
 *===========================================================================
 * Description: Function pointer type for cbc cipher calculation.
 * Parameters:  out    - pointer to buffer for the result.
 *              in     - pointer to buffer with the data to encrypt/decrypt.
 *              length - number of bytes to encrypt/decrypt.
 *              key    - pointer to buffer with the key.
 *              iv     - pointer to buffer with the initialization vector.
 *              enc    - 1 means encrypt. 0 means decrypt.
 * Returns:     -1 = error
 *               0 = timeout
 *               1 = ok
 */
 typedef int (* Iphwcrypto_cbc_cipher_calc) (Ip_u8 *out, IP_CONST Ip_u8 *in, Ip_u32 length, void *key, Ip_u8 *iv, int enc);


/*
 *===========================================================================
 *                  Iphwcrypto_ecb_cipher_calc
 *===========================================================================
 * Description: Function pointer type for ecb cipher calculation.
 * Parameters:  out    - pointer to buffer for the result.
 *              in     - pointer to buffer with the data to encrypt/decrypt.
 *              length - number of bytes to encrypt/decrypt.
 *              key    - pointer to buffer with the key.
 *              enc    - 1 means encrypt. 0 means decrypt.
 * Returns:     -1 = error
 *               0 = timeout
 *               1 = ok
 */
typedef int (* Iphwcrypto_ecb_cipher_calc) (Ip_u8 *out, IP_CONST Ip_u8 *in, Ip_u32 length, void *key, int enc);


/*
 *===========================================================================
 *                  Iphwcrypto_random_gen
 *===========================================================================
 * Description: Function pointer type for random number generation
 * Parameters:  data   - buffer to place the random data in.
 *              length - requested number of bytes of random data.
 * Returns:     -1 = error
 *               0 = timeout
 *               1 = ok
 */
typedef int (* Iphwcrypto_random_gen) (Ip_u8 *data, Ip_u32 length);


/*
 *===========================================================================
 *                  Iphwcrypto_mod_exp
 *===========================================================================
 * Description: Function pointer type for modular exponentiation. (b^e mod m)
 *              The size of the base and exponent buffers are equal to the
 *              modulus length. If the base or exponent are smaller
 *              than the modulus the numbers are padded with leading zeros
 *              up to the modulus length. The size of the result buffer
 *              is equal to the modulus length. If the result of the modular
 *              exponentiation is smaller than the modulus the result must
 *              be zero padded with leading zeros.
 * Parameters:  out    - pointer to buffer for the result.
 *              base   - pointer to buffer with the base.
 *              e      - pointer to buffer with the exponent.
 *              modlen - length of modulus.
 * Returns:     -1 = error
 *               0 = timeout
 *               1 = ok
 */
typedef int (* Iphwcrypto_mod_exp) (Ip_u8 *out, IP_CONST Ip_u8 *base, IP_CONST Ip_u8 *e, IP_CONST Ip_u8 *mod, Ip_u32 modlen);


/*
 *===========================================================================
 *                  Iphwcrypto_esp_cbc_sa
 *===========================================================================
 * Tunnel descriptor block for ipsec esp.
 *
 */
typedef struct Iphwcrypto_esp_cbc_sa_struct
{
    int            alg;         /* ESP algorithm */
    unsigned char *data;        /* Pointer to packet data at start of ESP header */
    int            hdrlen;      /* Offset to payload data (includes ESP header and iv) */

    unsigned char *akey;        /* Authentication key */
    int            akeylen;     /* Authentication key length */
    int            hashlen;     /* Algorithm digest length */
    int            authlen;     /* Authenticator length */

    unsigned char *ekey;        /* Encryption key */
    int            ekeylen;     /* Encryption key length */
    unsigned char *iv;          /* Initialization vector */
    int            ivlen;       /* Initialization vector length */
    void          *ipsec_sa;   /* Pointer to ipsec internal sa - do not use */
}
Iphwcrypto_esp_cbc_sa;


#ifdef IPIPSEC2
/*
 *===========================================================================
 *                  Iphwcrypto_ipsec_esp
 *===========================================================================
 * Description: Function pointer type for ipsec esp.
 *
 *              The esp function shall decrypt the data and calculate the
 *              message authentication code for ingress packets. For egress
 *              packets the function shall encrypt the data and calculate the
 *              message authentication code. The function shall not remove
 *              any headers or add message authentication codes.
 *
 *              The packet data parameter points to the start of the ESP header.
 *
 *              The length parameter equals the the total length of the packet
 *              excluding IP header. Ingress packets includes the hmac in the
 *              length while egress packets does not.
 *
 *              The sa parameter includes all necessary keys and algorithm
 *              specifiers for the cipher and hash calculation.
 *
 *              The param, sa and pkt parameters are used for asynchronous operation.
 *              In asynchronous ipsec operation the user must create a copy of
 *              the param and sa structures as the original pointers may not be valid
 *              when the packet is re-input or re-output. The pkt pointer must
 *              be kept unchanged.
 *
 *              Return code 1 means synchronous operation while 2 means asynchronous
 *              operation where the packets will be re-input or re-output when the
 *              esp operation completes.
 *
 * Parameters:  data   - pointer to the packet data.
 *              length - length of the packet.
 *              sa    - pointer to the sa (tunnel descriptor block).
 *              param  - pointer to ipsec parameters.
 *              digest - pointer the message autentication code.
 *              pkt    - pointer to the packet structure.
 *
 * Returns:     2 = kept.
 *              1 = ok
 *              0 = timeout
 *             -1 = error
 */
typedef int (* Iphwcrypto_ipsec_esp) (Ip_u8 *data, Ip_u32 length, Iphwcrypto_esp_cbc_sa *sa, Ip_u8 *digest, Ipipsec_param *param, Ipcom_pkt *pkt);
#endif

/*
 ****************************************************************************
 * 6                    FUNCTIONS
 ****************************************************************************
 */
/*******************************************************************************
*
* iphwcrypto_engine_add - add an engine to the system
*
* This routine adds a hardware cryptography engine to the system.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \i <name>
* The name of the engine.
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_NO_MEMORY = out of memory,
* IPCOM_ERR_INVALID_ARG = invalid argument, IPCOM_ERR_FAILED = other error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_add
    (
    const char *id,
    const char *name
    );


/*******************************************************************************
*
* iphwcrypto_engine_remove - remove an engine from the system
*
* This routine removes an engine from the system.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_INVALID_ARG = invalid argument,
* IPCOM_ERR_FAILED = other error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_remove
    (
    const char *id
    );

#ifdef IPCRYPTO
/*******************************************************************************
*
* iphwcrypto_engine_add_digest - add a digest method to an engine
*
* This routine adds a digest method to an engine.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \i <type>
* The type of digest.
*
* \i <ctx_size>
* The number of bytes to be allocated for the context.
*
* \i <init>
* A pointer to the digest context initialization function.
*
* \i <update>
* A pointer to the digest update function.
*
* \i <final>
* A pointer to the digest final function.
*
* \i <copy>
* A pointer to the digest copy function.
*
* \i <cleanup>
* A pointer to the digest cleanup function.
*
* \i <last>
* A flag indicating the last digest to be added. 1 means that this is the last in the collection
* of digests to be
* added to the engine. 0 means that more will be added.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_NO_MEMORY = out of memory,
* IPCOM_ERR_INVALID_ARG = invalid argument, IPCOM_ERR_FAILED = other error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_add_digest
    (
    const char *id,
    int type,
    int ctx_size,
    Iphwcrypto_digest_init init,
    Iphwcrypto_digest_update update,
    Iphwcrypto_digest_final  final,
    Iphwcrypto_digest_copy copy,
    Iphwcrypto_digest_cleanup cleanup,
    int last
    );

/*******************************************************************************
*
* iphwcrypto_engine_register_digests - register added digest methods
*
* This routine registers digest methods that have been added to an engine, and
* sets the engine as the default engine for digest operations.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_FAILED = error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_register_digests
    (
    const char *id
    );

/*******************************************************************************
*
* iphwcrypto_engine_add_cbc_cipher - add a CBC cipher method to an engine
*
* This routine adds a CBC cipher method to an engine.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \i <type>
* The type of cipher.
*
* \i <c>
* A pointer to the CBC cipher function.
*
* \i <last>
* A flag indicating the last cipher to be added. 1 means that this is the last in the
* collection of ciphers to be added
* to the engine. 0 means that more will be added.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_NO_MEMORY = out of memory,
* IPCOM_ERR_INVALID_ARG = invalid argument, IPCOM_ERR_FAILED = other error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_add_cbc_cipher
    (
    const char *id,
    int type,
    Iphwcrypto_cbc_cipher_calc c,
    int last
    );

/*******************************************************************************
*
* iphwcrypto_engine_add_ecb_cipher - add an ECB cipher method to an engine
*
* This routine adds an ECB cipher method to an engine.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \i <type>
* The type of cipher.
*
* \i <c>
* A pointer to the ECB cipher function
*
* \i <last>
* A flag indicating the last cipher to be added. 1 means that this is the last in the
* collection of ciphers to be
* added to the engine. 0 means that more will be added.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_NO_MEMORY = out of memory,
* IPCOM_ERR_INVALID_ARG = invalid argument, IPCOM_ERR_FAILED = other error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_add_ecb_cipher
    (
    const char *id,
    int type,
    Iphwcrypto_ecb_cipher_calc c,
    int last
    );

/*******************************************************************************
*
* iphwcrypto_engine_register_ciphers - register added cipher methods
*
* This routine registers cipher methods that have been added to an engine
* and sets the engine as the default engine for cipher operations.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_FAILED = error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_register_ciphers
    (
    const char *id
    );

/*******************************************************************************
*
* iphwcrypto_engine_add_random - add random number generation method to an engine
*
* This routine adds a random number generation method to an engine.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \i <r>
* A pointer to the random number generation function.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_INVALID_ARG = invalid argument,
* IPCOM_ERR_FAILED = other error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_add_random
    (
    const char *id,
    Iphwcrypto_random_gen r
    );
/*******************************************************************************
*
* iphwcrypto_engine_register_random - register added random number generator
*
* This routine registers a random number generator that has been added
* to an engine and sets the engine as the default engine for random number generation.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_FAILED = error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_register_random
    (
    const char *id
    );

/*******************************************************************************
*
* iphwcrypto_engine_add_dh - add Diffie-Hellman method to an engine
*
* This routine adds a Diffie-Hellman method to an engine.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \i <modexp>
* A pointer the modular exponentiation function.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_INVALID_ARG = invalid argument,
* IPCOM_ERR_FAILED = other error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_add_dh
    (
    const char *id,
    Iphwcrypto_mod_exp modexp
    );

/*******************************************************************************
*
* iphwcrypto_engine_register_dh - register added Diffie-Hellman method
*
* This routine registers a Diffie-Hellmand method that has been added to
* an engine and sets the engine as the default engine for DH operations.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_FAILED = error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_register_dh
    (
    const char *id
    );

/*******************************************************************************
*
* iphwcrypto_engine_add_rsa - add RSA method to an engine
*
* This routine adds an RSA method to an engine.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \i <modexp>
* A pointer the modular exponentiation function.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_INVALID_ARG = invalid argument,
* IPCOM_ERR_FAILED = other error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_add_rsa
    (
    const char *id,
    Iphwcrypto_mod_exp modexp
    );

/*******************************************************************************
*
* iphwcrypto_engine_register_rsa - register added RSA method
*
* This routine registers an RSA method that has been added to an engine and
* sets the engine as the default engine for RSA operations.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_FAILED = error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_register_rsa
    (
    const char *id
    );

/*******************************************************************************
*
* iphwcrypto_engine_add_dsa - add DSA method to an engine
*
* This routine adds a DSA method to an engine.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \i <modexp>
* A pointer the modular exponentiation function.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_INVALID_ARG = invalid argument,
* IPCOM_ERR_FAILED = other error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_add_dsa
    (
    const char *id,
    Iphwcrypto_mod_exp modexp
    );

/*******************************************************************************
*
* iphwcrypto_engine_register_dsa - register added DSA method
*
* This routine registers a DSA method that has been added to an engine
* and sets the engine as the default engine for DSA operations.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_FAILED = error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_engine_register_dsa
    (
    const char *id
    );
#endif /* #ifdef IPCRYPTO */

#ifdef IPIPSEC2
/*******************************************************************************
*
* iphwcrypto_ipsec_engine_add_esp - add IPsec ESP method to an engine
*
* This routine adds an IPsec ESP method to an engine.
* Either the ESP input or the ESP output function pointers may be null.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \i <type>
* The type of ESP.
*
* \i <esp_in>
* A pointer to the ESP input function.
*
* \i <esp_out>
* A pointer to the ESP output function.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_INVALID_ARG = invalid argument,
* IPCOM_ERR_FAILED = other error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_ipsec_engine_add_esp
    (
    const char *id,
    int type,
    Iphwcrypto_ipsec_esp esp_in,
    Iphwcrypto_ipsec_esp esp_out
    );

/*******************************************************************************
*
* iphwcrypto_ipsec_engine_register_esp - register added IPsec ESP method
*
* This routine registers an IPsec ESP method that has been added to an engine
* and sets the engine as the default engine for IPsec ESP operations.
*
* Parameters:
* \is
* \i <id>
* The id of the engine.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_FAILED = error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_ipsec_engine_register_esp
    (
    const char *id
    );

/*******************************************************************************
*
* iphwcrypto_ipsec_esp_re_input - re-input IPsec ESP packet
*
* This routine re-inputs an IPsec ESP packet after an asynchronous operation.
*
* Parameters:
* \is
* \i <sa>
* A pointer to the SA (tunnel descriptor block).
*
* \i <param>
* A pointer to the IPsec parameters.
*
* \i <pkt>
* A pointer to the packet structure.
*
* \i <digest>
* A pointer the calculated digest.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_FAILED = error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_ipsec_esp_re_input
    (
    Iphwcrypto_esp_cbc_sa *sa,
    Ipipsec_param *param,
    Ipcom_pkt *pkt,
    Ip_u8 *digest
    );

/*******************************************************************************
*
* iphwcrypto_ipsec_esp_re_output - re-output IPsec ESP packet
*
* This routine re-outputs an IPsec ESP packet after an asynchronous operation.
*
* Parameters:
* \is
* \i <sa>
* A pointer to the SA (tunnel descriptor block).
*
* \i <param>
* A pointer to the IPsec parameters.
*
* \i <pkt>
* A pointer to the packet structure.
*
* \i <digest>
* A pointer the calculated digest.
*
* \ie
*
* RETURNS: IPCOM_SUCCESS = ok, IPCOM_ERR_FAILED = error
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC Ip_err iphwcrypto_ipsec_esp_re_output
    (
    Iphwcrypto_esp_cbc_sa *sa,
    Ipipsec_param *param,
    Ipcom_pkt *pkt,
    Ip_u8 *digest
    );

/*******************************************************************************
*
* iphwcrypto_ipsec_esp_pkt_free - return previously kept packet to the system
*
* This routine returns a previously kept packet to the system. It must
* be called if an asynchronous ESP operation fails or if the call to
* iphwcrypto_ipsec_esp_re_output() or iphwcrypto_ipsec_esp_re_input() fails.
*
* Parameters:
* \is
* \i <pkt>
* A pointer to the packet structure.
*
* \ie
*
* RETURNS: Nothing.
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC void iphwcrypto_ipsec_esp_pkt_free
    (
    Ipcom_pkt *pkt
    );

#endif  /* #ifdef IPIPSEC2 */

#ifdef __cplusplus
}
#endif

#endif

/*
 ****************************************************************************
 *                      END OF FILE
 ****************************************************************************
 */
