/* ipssh.h - Public API of Wind River SSH */

/*
 ******************************************************************************
 *                     HEADER FILE
 *
 *     Document no: @(#) $Name: release6_9_2_binmsp $ $RCSfile: ipssh.h,v $ $Revision: 1.55.4.1 $
 *     $Source: /home/interpeak/CVSRoot/ipssh/include/ipssh.h,v $
 *     $Author: ulf $ $Date: 2011-03-05 09:39:08 $
 *     $State: Exp $ $Locker:  $
 *
 *     INTERPEAK_COPYRIGHT_STRING
 *     Design and implementation by Roger Boden <roger@interpeak.se>
 ******************************************************************************
 */
#ifndef IPSSH_H
#define IPSSH_H

/*
 ****************************************************************************
 * 1                    DESCRIPTION
 ****************************************************************************
 */

/*
DESCRIPTION
This library contains the API for Wind River SSH.
*/


/*
 ****************************************************************************
 * 2                    CONFIGURATION
 ****************************************************************************
 */
#include <ipssh_config.h>

/*
 ****************************************************************************
 * 3                    INCLUDE FILES
 ****************************************************************************
 */

#include <ipcom_sock.h>
#include <ipcom_list.h>
#include <ipcom_file.h>
#include <ipcom_shell.h>

#include <openssl/dsa.h>
#ifdef IPSSH_USE_RSA
#include <openssl/rsa.h>
#endif
#include <openssl/evp.h>
#include <openssl/hmac.h>

#ifdef __cplusplus
extern "C"
{
#endif

/*
 ****************************************************************************
 * 4                    DEFINES
 ****************************************************************************
 */

#define IPSSH_RELEASE 60900

#define IPSSH_HEX 1
#define IPSSH_BUBBLE_BABBLE 2

#define IPSSH_SFTP_ROOT_DIR (IPCOM_SHELL_CTX_IPSSH_BASE)

/*
 ****************************************************************************
 * 5                    TYPES
 ****************************************************************************
 */
    /* Forward declaration */
    struct Ipssh_conn_st;

    typedef struct Ipssh_srv_keys_st
    {
#ifdef IPSSH_USE_RSA
        RSA* rsa_key;
#endif
        DSA* dsa_key;
    } Ipssh_srv_keys;

    typedef struct Ipssh_clt_info_st
    {
        char userid[32];
        char service[16];
        char clt_addr[40];
        Ip_pid_t pid;
        char auth_method[16];
        char cipher [16];
        char mac [16];
        char ssh_clt_sw[32];
    } Ipssh_clt_info;


#ifdef IPSSH_USE_SFTP
    struct Ipssh_sftp_func_cb_st
    {
        char type[16];
        /* File mgnt callbacks */
        Ip_fd (*open_cb)(const char *pathname, int omode, Ip_mode_t attrs);
        Ip_err (*close_cb)(Ip_fd fd);
        Ip_err (*stat_cb)(const char* path, struct Ip_stat* buf);
        Ip_ssize_t(*read_cb)(Ip_fd fd, char* data, Ip_size_t len);
        Ip_ssize_t(*write_cb)(Ip_fd fd, const char* data, Ip_size_t len);
        Ip_off_t (*lseek_cb)(Ip_fd fd, Ip_u64 offset, int whence);
        /* Directory mgnt callbacks */
        IP_DIR* (*opendir_cb)(const char* path);
        int (*closedir_cb)(IP_DIR* dirp);
        struct Ip_dirent* (*readdir_cb)(IP_DIR *dirp);
        int (*mkdir_cb)(const char* path, Ip_mode_t mode);
        int (*rmdir_cb)(const char* path);
        int (*unlink_cb)(const char* path);
        int (*rename_cb)(const char* oldpath, const char* newpath);
    };
    typedef struct Ipssh_sftp_func_cb_st Ipssh_sftp_func_cb;
#endif

/*
 ****************************************************************************
 * 6                    FUNCTIONS
 ****************************************************************************
 */

/*******************************************************************************
*
* ipssh_conn_new - create a new SSH connection handle
*
* This routine creates an SSH connection handle.
*
* RETURNS: A connection handle or 'IP_NULL', if the operation fails.
*
* ERRNO:
*/
    IP_PUBLIC struct Ipssh_conn_st* ipssh_conn_new
    (
     void
    );

    IP_PUBLIC const char* ipssh_version(void);

/*******************************************************************************
*
* ipssh_stop_spawn - stop a spawned process
*
* DESCRIPTION
* This routine stops a spawned process.
*
* Parameter:
* \is
* \i <pid>
* The process ID of the process to stop.
* \ie
*
* RETURNS: 'IPCOM_SUCCESS' or 'IPCOM_ERR_NOT_INSTALLED,' if there is no spawned
* process with the given process ID.
*
* ERRNO:
*/
    IP_PUBLIC Ip_err ipssh_stop_spawn
    (
     Ip_pid_t pid
    );


/*******************************************************************************
*
* ipssh_stop_all_spawns - stop all spawned IPSSH tasks
*
* This routine stops all spawned IPSSH tasks. This is equivalent to logging out all
* users.
*
* Parameters:
*
* None.
*
* RETURNS: 'IPCOM_SUCCESS' or 'IPCOM_ERR_FAILED'
*
* ERRNO:
*/
    IP_PUBLIC Ip_err ipssh_stop_all_spawns(void);


/*******************************************************************************
*
* ipssh_evp_pkey_cmp - compare two public keys
*
* This routine compares two public keys. It is a utility function to aid
* implementers of 'ipssh_validate_public_key'.
*
* Parameters:
* \is
* \i <key1>
* A pointer to the first public key to be used in the comparison.
* \i <key2>
* A pointer to the second public key to be used in the comparison.
* \ie
*
* RETURNS: 0, if keys are equal; non-zero, otherwise.
*
* ERRNO:
*/
    IP_PUBLIC Ip_s32 ipssh_evp_pkey_cmp
    (
     EVP_PKEY* key1,
     EVP_PKEY* key2
    );

/*******************************************************************************
*
* ipssh_get_clt_info - return information on  logged-in client
*
* This routine returns information on logged-in client.
*
* Parameters:
* \is
* \i <clt_info>
* A pointer to an 'Ipssh_clt_info' structure.
*
* \i <pos>
* An index value indicating the client for which information is being returned
* \ie
*
* RETURNS: 'IPCOM_SUCCESS', or 'IPCOM_ERR_NOT_FOUND', if <pos> exceeds the
* number of logged in clients.
*
* ERRNO:
*/
    IP_PUBLIC Ip_err ipssh_get_clt_info
    (
     Ipssh_clt_info* clt_info,
     int pos
    );

/*******************************************************************************
*
* ipssh_send_shell_stdout_data - send 'stdout' data to the SSH client
*
* Parameters:
* \is
* \i <ssh_ctx>
* A handle to the ssh connection context.
* \i <shell_ctx>
* Handle to the shell context. This handle is returned by the shell start
* callback and transparently conveyed by IPSSH.
* \i <data>
* Pointer to the 'stdout' data
* \i <len>
* Length of the 'stdout' data.
* \ie
*
* RETURNS: The number of bytes written or 'IPCOM_ERR_FAILED', if no bytes were
* written. Note that for SSH v2 connections, the number of bytes that are
* possible to send is affected the current channel window size. This means that
* fewer bytes than requested may be sent. The caller must inspect the return
* value and take appropriate action if not all data could be written.
* 'Appropriate action' typically means wait a while and try again.
*
* ERRNO:
*/
    IP_PUBLIC int ipssh_send_shell_stdout_data
    (
     void* ssh_ctx,
     void* shell_ctx,
     const char* data,
     Ip_ssize_t len
    );

/*******************************************************************************
*
* ipssh_shell_exit - report that a shell has terminated
*
* This routine informs IPSSH that a shell has terminated. If the shell is the
* last shell connected to the SSH connection, the connection is released.
*
* Parameters:
* \is
* \i <ssh_ctx>
* A handle to the SSH connection context.
* \i <shell_ctx>
* Handle to the shell context. This handle is returned by the shell start
* callback and transparently conveyed by IPSSH.
* \ie
*
* RETURNS:  'IPCOM_SUCCESS' or an error code.
*
* ERRNO:
*/
    IP_PUBLIC Ip_err ipssh_shell_exit
    (
     void* ssh_ctx,
     void* shell_ctx
    );

/*******************************************************************************
*
* ipssh_key_fingerprint2 - generate a fingerprint of a public key
*
* Generates a fingerprint of a public key.
*
* Parameters:
* \is
* \i <key>
* Public key for which a fingerprint is to be generated.
* \i <key_type>
* The key type to generate a fingerprint of. Allowed values are: EVP_PKEY_DSA for SSHv2 DSA keys, EVP_PKEY_RSA for SSHv2 RSA keys and IPSSH_V1_RSA_ID for SSHv1 RSA keys.
* \i <fp>
* Pointer to a pointer to the generated fingerprint. This pointer must be freed
* by the caller.
* \i <fp_type>
* Specifies the type of fingerprint to generate. Two fingerprint formats are
* supported: 'IPSSH_HEXIP' and' SSH_BUBBLE_BABBLE'.
* \ie
*
* RETURNS: 'IPCOM_SUCCESS' if the fingerprint was generated, otherwise
* 'IPCOM_ERR_FAILED'.
*
* ERRNO:
*
*/
    IP_PUBLIC Ip_err ipssh_key_fingerprint2
    (
     EVP_PKEY* key,
     int key_type,
     char** fp,
     int fp_type
    );

/*******************************************************************************
*
* ipssh_key_fingerprint - generate a fingerprint of a public key
*
* Deprecated, please use ipssh_key_fingerprint2. Generates a fingerprint of a public key.
*
* Parameters:
* \is
* \i <key>
* Public key for which a fingerprint is to be generated.
* \i <fp>
* Pointer to a pointer to the generated fingerprint. This pointer must be freed
* by the caller.
* \i <fp_type>
* Specifies the type of fingerprint to generate. Two fingerprint formats are
* supported: 'IPSSH_HEXIP' and' SSH_BUBBLE_BABBLE'.
* \ie
*
* RETURNS: 'IPCOM_SUCCESS' if the fingerprint was generated, otherwise
* 'IPCOM_ERR_FAILED'.
*
* ERRNO:
*
*/
    IP_PUBLIC Ip_err ipssh_key_fingerprint
    (
     EVP_PKEY* key,
     char** fp,
     int fp_type
    );

/*******************************************************************************
*
* ipssh_get_clt_fd - return the socket descriptor of a client
*
* This routine returns the socket descriptor of a client.
*
* If IPSSH is configured to listen to several ports and each port is connected
* to a different shell, it is important to be able to determine what port a
* client connected on in the shell start callback routine, so that the start
* callback can initiate the correct shell for each connection. This routine
* returns the socket descriptor, which in turn is used in a call to
* ipcom_getpeername() to get the port the client connected on.
*
* Parameter:
* \is
* \i <ssh_ctx>
* A handle to the SSH connection context.
* \ie
*
* RETURNS: The socket descriptor of the client connection.
*
* ERRNO:
*/
    IP_PUBLIC Ip_fd ipssh_get_clt_fd
    (
     void* ssh_ctx
    );

#ifdef IPSSH_USE_SFTP
/*******************************************************************************
*
* ipssh_get_sftp_func_cb -  perform file operations on a specified file
*
* This callback routine is called once for each request for a file operation on
* a specific path. It returns a set of pointers to file-system routines that are
* called during the processing of the request. Note that a typical file
* operation, such as a get or a put operation, consists of several SFTP
* messages, so that a single file operation request may result in several calls
* to the routine pointers.
*
* Parameter:
* \is
* \i <path>
* The path to the file on which a file operation is to be performed.
* \ie
*
* RETURNS: A pointer to 'Ipssh_sftp_func_cb', which is defined as follows:
* \cs
* struct Ipssh_sftp_func_cb_st
* {
* 	char type[16];
* 	/@ File management callbacks @/
* 	Ip_fd (*open_cb)(const char *pathname, int omode, Ip_mode_t attrs);
* 	Ip_err (*close_cb)(Ip_fd fd);
* 	Ip_err (*stat_cb)(const char* path, struct Ip_stat* buf);
* 	int (*read_cb)(Ip_fd fd, char* data, Ip_size_t len);
* 	int (*write_cb)(Ip_fd fd, const char* data, Ip_size_t len);
* 	int (*lseek_cb)(Ip_fd fd, Ip_u64 offset, int whence);
* 	/@ Directory mgnt callbacks @/
* 	IP_DIR* (*opendir_cb)(const char* path);
* 	int (*closedir_cb)(IP_DIR* dirp);
* 	struct Ip_dirent* (*readdir_cb)(IP_DIR *dirp);
* 	int (*mkdir_cb)(const char* path, Ip_mode_t mode);
* 	int (*rmdir_cb)(const char* path);
* };
* typedef struct Ipssh_sftp_func_cb_st Ipssh_sftp_func_cb;
* \ce
*
* ERRNO:
*/
    IP_PUBLIC Ipssh_sftp_func_cb* ipssh_get_sftp_file_func_cb
    (
     void
    );
#endif

    IP_PUBLIC void* ipssh_sock_shell_start(void* ssh_ctx, const char* user, Ipcom_shell_ctx* sh_ctx);
    IP_PUBLIC Ip_err ipssh_sock_shell_stdin(void* ssh_ctx, void* shell_ctx, const char* data, int len);
    IP_PUBLIC Ip_err ipssh_sock_shell_stop(void* ssh_ctx, void* shell_ctx);

    /* Deprecated */
    IP_PUBLIC Ip_err ipssh_set_host_keys(Ipssh_srv_keys* host_keys);

#ifdef __cplusplus
}
#endif

#endif


/*
 ****************************************************************************
 *                      END OF FILE
 ****************************************************************************
 */
