/* ipssh_config.h - Configuration API of Wind River SSH */

/*
 ******************************************************************************
 *                     HEADER FILE
 *
 *     Document no: @(#) $Name: release6_9_2_binmsp $ $RCSfile: ipssh_config.h,v $ $Revision: 1.61.4.1 $
 *     $Source: /home/interpeak/CVSRoot/ipssh/config/ipssh_config.h,v $
 *     $Author: ulf $ $Date: 2011-03-05 09:39:08 $
 *     $State: Exp $ $Locker:  $
 *
 *     INTERPEAK_COPYRIGHT_STRING
 *     Design and implementation by Roger Boden <roger@interpeak.se>
 ******************************************************************************
 */
#ifndef IPSSH_CONFIG_H
#define IPSSH_CONFIG_H

/*
 ****************************************************************************
 * 1                    DESCRIPTION
 ****************************************************************************
 */

/*
DESCRIPTION
This library contains the APIs used for configuration of Wind River SSH.
*/


/*
 ****************************************************************************
 * 2                    CONFIGURATION
 ****************************************************************************
 */

/*
 ****************************************************************************
 * 3                    INCLUDE FILES
 ****************************************************************************
 */

#include <ipcom_type.h>
#include <ipcom_cstyle.h>
#include <ipcom_config.h>
#include <openssl/dsa.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 ****************************************************************************
 * 4                    CONFIGURATION
 ****************************************************************************
 */
#ifdef IP_DEBUG
#define IPSSH_DEBUG
#endif

#ifdef IP_ASSERT
#define IPSSH_ASSERT
#endif

/*
 *===========================================================================
 *                         syslog build-time configuration
 *===========================================================================
 */
#ifdef IPSSH_DEBUG
#define IPSSH_SYSLOG_PRIORITY IPCOM_LOG_DEBUG
#else
#define IPSSH_SYSLOG_PRIORITY IPCOM_LOG_ERR
#endif

/*
 *===========================================================================
 *                         IPSSH_USE_STOP_SPAWN
 *===========================================================================
 */
#ifndef IP_SIZE
#define IPSSH_USE_STOP_SPAWN
#endif

/*
 *===========================================================================
 *                         IPSSH_USE_SFTP
 *===========================================================================
 */
#ifndef IP_SIZE
#define IPSSH_USE_SFTP
#endif

/*
 *===========================================================================
 *                         IPSSH_USE_SFTP_CLT
 *===========================================================================
 */
#ifdef IPSSH_USE_SFTP
#define IPSSH_USE_SFTP_CLT
#endif


/*
 *===========================================================================
 *                         IPSSH_USE_SFTP_CLT_CMD
 *===========================================================================
 */
#ifdef IPSSH_USE_SFTP_CLT
#define IPSSH_USE_SFTP_CLT_CMD
#endif

/*
 *===========================================================================
 *                         IPSSH_USE_V1
 *===========================================================================
 */
#ifndef IP_SIZE
#define IPSSH_USE_V1
#endif


/*
 *===========================================================================
 *                         ENCRYPTION ALGORITHMS
 *===========================================================================
 * Use the defines below to control what encryption algorithms that will be
 * supported by IPSSH.
 */
#ifndef OPENSSL_NO_DES
#define IPSSH_USE_DES
#endif
#ifndef OPENSSL_NO_AES
#define IPSSH_USE_AES
#endif
#ifndef OPENSSL_NO_CAST
#define IPSSH_USE_CAST
#endif
#ifndef OPENSSL_NO_RC4
#define IPSSH_USE_ARCFOUR
#endif
#ifndef OPENSSL_NO_BF
#define IPSSH_USE_BLOWFISH
#endif


/*
 *===========================================================================
 *                         HASH ALGORITHMS
 *===========================================================================
 * Use the defines below to control hash encryption algorithms that will be
 * supported by IPSSH.
 */
#ifndef OPENSSL_NO_SHA
#define IPSSH_USE_SHA1
#endif

#ifndef OPENSSL_NO_MD5
#define IPSSH_USE_MD5
#endif

/*
 *===========================================================================
 *                         IPSSH_USE_RSA
 *===========================================================================
 * This define controls whether RSA support shall be included. RSA is required
 * for SSH v1 connections and can be used for client authentication in SSH v2
 * connections.
 */
#ifndef OPENSSL_NO_RSA
#define IPSSH_USE_RSA
#endif

/*
 *===========================================================================
 *                         IPSSH_USE_KEY_FINGERPRINT
 *===========================================================================
 * Controls whether functions for key fingerprint generation shall be compiled in.
 */
#ifndef IP_SIZE
#define IPSSH_USE_KEY_FINGERPRINT
#endif

/*
 *===========================================================================
 *                         IPSSH_USE_DH_GROUP_EX
 *===========================================================================
 * Controls whether support for RFC 4419, SSH DH Group Exchange, shall be
 * compiled in.
 */
#define IPSSH_USE_DH_GROUP_EX

/*
 *===========================================================================
 *                         IPSSH_USE_DH_GROUP_EX_EXAMPLE_MODULI_FILE
 *===========================================================================
 * Controls whether an example DH group exchange moduli file shall be
 * automatically generated at boot. The example moduli file is a pre-generated
 * file that is simply compiled in as an ascii blob and written to the moduli
 * file
 */
#ifdef IPSSH_USE_DH_GROUP_EX
#define IPSSH_USE_DH_GROUP_EX_EXAMPLE_MODULI_FILE
#endif

/*
 *===========================================================================
 *                         IPSSH_SFTP_START_DIR
 *===========================================================================
 * Start directory for sftp connections.
 */
#ifdef IPSSH_USE_SFTP
#define IPSSH_SFTP_START_DIR IPCOM_FILE_ROOT
#endif


/*
 *===========================================================================
 *                         IPSSH_SHELLCMD_PROC_PRIO
 *===========================================================================
 * Process priority of IPSSH shell commands.
 */
#define IPSSH_SHELLCMD_PROC_PRIO     IPCOM_PRIORITY_DEFAULT

/*
 *===========================================================================
 *                         IPSSH_DAEMON_PROC_PRIO
 *===========================================================================
 * Process priority of IPSSH deamon process.
 */
#define IPSSH_DAEMON_PROC_PRIO     IPCOM_PRIORITY_DEFAULT

/*
 *===========================================================================
 *                         IPSSH_SPAWN_PROC_PRIO
 *===========================================================================
 * Process priority of spawned IPSSH processes.
 * The spawned IPSSH processes perform public key operations during the handshake.
 * These operations are CPU intensive and it is therefore a good idea to run the
 * spawned processes at a lower priority than all processes that require real time
 * characteristics.
 */
#define IPSSH_SPAWN_PROC_PRIO     2

/*
 *===========================================================================
 *                         IPSSH_ECHO_STDIN
 *===========================================================================
 * Set this define if you want IPSSH to echo data received on stdin on terminal
 * connections. This is used for shells that do not echo data.
#define IPSSH_ECHO_STDIN
 */

/*
 *===========================================================================
 *                         IPSSH_CHOWN_SOCKET_CB
 *===========================================================================
 * Set this define to the name of function that changes the socket ownership
 * from one task to another. The function shall have the following signature:
 * void IPSSH_CHOWN_SOCKET_CB(Ip_fd sock, Ip_pid_t pid);
#define IPSSH_CHOWN_SOCKET_CB chown_socket
 */

/*
 *===========================================================================
 *                         IPSSH_START_DIR_MAX_LEN
 *===========================================================================
 * The maximum length of the sftp start directory path.
 */
#define IPSSH_START_DIR_MAX_LEN 128


/*
 *===========================================================================
 *                         IPSSH_AUTH_BANNER_MAX_LEN
 *===========================================================================
 * The maximum number of characters in the authentication banner.
 */
#define IPSSH_AUTH_BANNER_MAX_LEN 256


/*
 ****************************************************************************
 * 6                    FUNCTIONS
 ****************************************************************************
 */
    /* Forward declaration */
    union Ip_sockaddr_union;
    struct Ipcom_shell_ctx_struct;

/*******************************************************************************
*
* ipssh_load_dsa_key - return the DSA server key to be used by the daemon
*
* This function is called when the IPSSH daemon is started. The function must
* return the DSA server key to be used by the daemon.
*
* Parameters:
*
* None.
*
* RETURNS: An RSA key or 'IP_NULL' to indicate that no RSA key is available.
* Returning will prevent the daemon from starting.
*
* ERRNO:
*/
    IP_PUBLIC DSA* ipssh_load_dsa_key(void);


#ifdef IPSSH_USE_RSA
#include <openssl/rsa.h>
/*******************************************************************************
*
* ipssh_load_rsa_key - return the RSA server key to be used by the daemon
*
* This function is called when the IPSSH daemon is started. The function must
* return the RSA server key to be used by the daemon.
*
* Parameters:
*
* None.
*
* RETURNS: An RSA key or 'IP_NULL' to indicate that no RSA key is available.
* Returning 'IP_NULL' will prevent the daemon from starting.
*
* ERRNO:
*/
    IP_PUBLIC RSA* ipssh_load_rsa_key(void);
#endif

#ifdef IPSSH_USE_SFTP
    struct Ipssh_sftp_func_cb_st; /* Forward declaration */
    IP_PUBLIC struct Ipssh_sftp_func_cb_st* ipssh_get_sftp_func_cb(const char* path);

/*******************************************************************************
*
* ipssh_sftp_check_access_cb -  check user\'s access to file system
*
* This callback routine checks whether the user is authorized to perform a file
* operation. It is called whenever the user initiates a file operation.
*
* Parameters:
* \is
* \i <user>
* ID of the user initiating the request.
* \i <action>
* The file operation requested. The following operations are possible:
*
* \is
* \i 'IPSSH_FXP_MKDIR()'
* Create a directory.
* \i 'IPSSH_FXP_RMDIR()'
* Delete a directory.
* \i 'IPSSH_FXP_REMOVE()'
* Delete a file.
* \i 'IPSSH_FXP_OPEN()'
* Read a file or write to a file, as indicated by the <flag> parameter.
* \ie
* \i <path>
* The path to the file.
* \i <flags>
* One of the following flags for opening a file (used only with the
* 'IPSSH_FXP_OPEN' file operation):
*
* \is
* \i 'IPSSH_FXP_READ'
* Open the file for reading.
* \i 'IPSSH_FXP_WRITE'
* Open the file for writing.
* \ie
* \ie
*
* RETURNS: Either 'IPCOM_SUCCESS' or an error code (see 'ipcom_err.h').
*
* ERRNO:
*/
    IP_PUBLIC Ip_err ipssh_sftp_check_access_cb
    (
     const char* user,
     int action,
     const char* path,
     int flags);
#endif


/*******************************************************************************
*
* ipssh_configure - function to place any custom initialization code in.
*
* This function is called at boot,
* before the IPSSH daemon is started. Any custom configuration should be
* performed in this function.
*
* Parameters:
*
* None.
*
* RETURNS: 'IPCOM_SUCCESS' or IPCOM_ERR_FAILED
* Returning anything but 'IPCOM_SUCCESS' will prevent the daemon from starting.
*
* ERRNO:
*/
    IP_GLOBAL Ip_err ipssh_configure(void);


/*******************************************************************************
*
* ipssh_shell_start_cb -  start a shell at user login
*
* This callback routine starts a shell when a user logs in. It returns a handle
* to the shell context, which is used by 'ipssh_shell_stdin_cb()' and
* ipssh_shell_stop_cb(). The SSH protocol allows several shells to be started on
* the same connection. The IPCOM shell does not support this capability, but SSH
* does. Hence, multiple shell on the same connection can only be used if a
* proprietary shell is integrated.
*
* Parameters:
* \is
* \i <ssh_ctx>
* A handle to the current SSH connection.
* \i <user>
* A user ID.
* \i <sh_ctx>
* A pointer to a shell context. The shell context is passad to the authentication
* callbacks and to the shell start callback. It can be used to convey parameters
* from the authentication functions to the shell.
* \ie
*
* RETURNS: Handle to the shell context. A return value of 'IP_NULL' releases the
* connection.
*
* ERRNO:
*/
    IP_PUBLIC void* ipssh_shell_start_cb
    (
     void* ssh_ctx,
     const char* user,
     struct Ipcom_shell_ctx_struct* sh_ctx
     );

/*******************************************************************************
*
* ipssh_sock_shell_start_cb -  create shell with socket connection
*
* This callback routine creates a shell and connects a TCP socket to the
* standard input and standard output of the shell.
*
* Parameters:
* \is
* \i <stdio_sock>
* A pointer to the standard-input file descriptor to be set.
* \i <client_fd>
* The file descriptor for the client connection, which can be used to obtain the
* IP address of the client.
* \ie
*
* RETURNS: Either 'IPCOM_SUCCESS' or an error code (see 'ipcom_err.h'). An
* error releases the SSH connection.
*
* ERRNO:
*/
    IP_PUBLIC Ip_err ipssh_sock_shell_start_cb
    (
     Ip_fd *stdio_sock,
     struct Ipcom_shell_ctx_struct* sh_ctx
    );

/*******************************************************************************
*
* ipssh_shell_welcome_msg_cb -  display welcome message at shell creation
*
* This callback routine outputs a welcome message or banner. It is called when a
* shell has been created and all SSH internal setup operations have been
* completed.
*
* Parameters:
* \is
* \i <ssh_ctx>
* A handle to the current SSH connection.
* \i <shell_ctx>
* A handle to the current shell context.
* \ie
*
* RETURNS: Either 'IPCOM_SUCCESS' or an error code (see 'ipcom_err.h'). An error
* releases the SSH connection.
*
* ERRNO:
*/
    IP_PUBLIC Ip_err ipssh_shell_welcome_msg_cb
    (
     void* ssh_ctx,
     void* shell_ctx
    );

/*******************************************************************************
*
* ipssh_shell_stdin_cb -  decrypt standard-input data and send to shell
*
* This callback routine decrypts standard-input data and delivers it to the
* shell. It is called whenever data is received on the SSH connection.
*
* 'Parameters':
* \is
* \i <ssh_ctx>
* A handle to the SSH connection context.
* \i <shell_ctx>
* A handle to the shell context. The handle was originally returned by
* ipssh_shell_start_cb(), and is transparently conveyed by SSH.
* \i <data>
* A pointer to standard-input data.
* \i <len>
* The length of the standard-input data.
* \ie
*
* RETURNS: Either 'IPCOM_SUCCESS' or an error code (see 'ipcom_err.h'). An error
* causes the connection to be released.
*
* ERRNO:
*/
    IP_PUBLIC Ip_err ipssh_shell_stdin_cb
    (
     void* ssh_ctx,
     void* shell_ctx,
     const char* data,
     int len
    );

/*******************************************************************************
*
* ipssh_shell_stop_cb -  terminate the shell
*
* This callback routine terminates a shell. It is called whenever a shell needs
* to terminate; for example, when the client disconnects.
*
* Parameters:
* \is
* \i <ssh_ctx>
* A handle to the SSH connection context.
* \i <shell_ctx>
* A handle to the shell context, as returned by ipssh_shell_start_cb() and
* transparently conveyed by SSH.
* \ie
*
* RETURNS: Either 'IPCOM_SUCCESS' or an error code (see 'ipcom_err.h').
*
* ERRNO:
*/
    IP_PUBLIC Ip_err ipssh_shell_stop_cb
    (
     void* ssh_ctx,
     void* shell_ctx
    );

    IP_PUBLIC Ip_err ipssh_set_win_size(void *shell_ctx, Ip_u32 cols, Ip_u32 rows);

/*******************************************************************************
*
* ipssh_validate_userid_pw_cb -  validate user\'s login ID and password
*
* This callback routine validates a user\'s login ID and password. The
* configuration file 'ipssh/config/ipssh_config'.'c' contains a sample
* implementation.
*
* Parameters:
* \is
* \i <user>
* The user ID provided by the client.
* \i <pw>
* The password provided by the client.
* \i <cookie>
* Pointer to a cookie for use by ipssh_shell_start_cb().
* \ie
*
* RETURNS: 'IPCOM_SUCCESS' for a valid user ID and password. All other return
* values cause SSH to reject the login attempt.
*
* ERRNO:
*/
    IP_PUBLIC Ip_err ipssh_validate_userid_pw_cb
    (
     const char* user,
     const char* pw,
     struct Ipcom_shell_ctx_struct* sh_ctx
     );

/*******************************************************************************
*
* ipssh_validate_pubkey_cb -  validate client\'s public key in SSH v2
*
* This callback routine validates public keys used for client authentication in
* SSH v2 connections. The example configuration file
* 'ipssh/config/ipssh_config'.'c' contains a sample implementation.
*
* Parameters:
* \is
* \i <userid>
* The user ID sent by the client.
* \i <pub_key>
* The public key used by the client for authentication.
* \i <cookie>
* A pointer to the location of a cookie for use by ipssh_shell_start_cb().
* \ie
*
* RETURNS: Either 'IPCOM_SUCCESS', for a valid user ID and public key, or an
* error code (see 'ipcom_err.h'). An error causes SSH to reject the login
* attempt.
*
* ERRNO:
*/
    IP_PUBLIC Ip_err ipssh_validate_pubkey_cb
    (
     const char* user,
     EVP_PKEY* pub_key,
     struct Ipcom_shell_ctx_struct* sh_ctx
     );

#ifdef IPSSH_USE_V1
/*******************************************************************************
*
* ipssh_validate_rsa_pubkey_v1_cb -  validate client public key in SSH v1
*
* This callback routine validates public RSA keys used for client authentication
* in SSH v1 connections. The configuration file 'ipssh_config'.'c' contains a
* sample implementation.
*
* Parameters:
* \is
* \i <userid>
* The user ID sent by the client.
* \i <modulus>
* The modulus of the key used by the client for authentication.
* \i <cookie>
* A pointer to the location of a cookie for use by ipssh_shell_start_cb().
* \ie
*
* RETURNS: An RSA key structure containing the client\'s complete public
* key, both modulus (n) and public exponent (e). A return value of 'IP_NULL'
* means that the public modulus does not match an authorized public key, in
* which case SSH rejects the login attempt.
*
* ERRNO:
*/
    IP_PUBLIC RSA* ipssh_validate_rsa_pubkey_v1_cb
    (
     const char* user,
     BIGNUM* modulus,
     struct Ipcom_shell_ctx_struct* sh_ctx
    );
#endif

    IP_PUBLIC Ip_err ipssh_auth_complete_cb(const char* user, struct Ipcom_shell_ctx_struct* sh_ctx);
    IP_PUBLIC Ip_err ipssh_validate_srv_public_key(EVP_PKEY* srv_key, const union Ip_sockaddr_union* srv_addr);
    IP_PUBLIC Ip_err ipssh_validate_pubkey_ssh2(const char* user, EVP_PKEY* pub_key, struct Ipcom_shell_ctx_struct* sh_ctx);

    IP_GLOBAL void ipssh_create_dh_gex_moduli_example_file(void);

/*
 ****************************************************************************
 * 7                    SANITY CHECKS
 ****************************************************************************
 */
#if defined(IPSSH_USE_V1) && !defined(IPSSH_USE_RSA)
#error RSA_REQUIRED_FOR_SSH_V1
#endif

#if !defined(IPSSH_USE_DES) && !defined(IPSSH_USE_CAST) && !defined(IPSSH_USE_ARCFOUR) && !defined(IPSSH_USE_BLOWFISH) && !defined(IPSSH_USE_AES)
#error AT_LEAST_ONE_ENCRYPTION_ALGORITHM_MUST_BE_DEFINED
#endif

#ifdef __cplusplus
}
#endif

#endif


/*
 ****************************************************************************
 *                      END OF FILE
 ****************************************************************************
 */
