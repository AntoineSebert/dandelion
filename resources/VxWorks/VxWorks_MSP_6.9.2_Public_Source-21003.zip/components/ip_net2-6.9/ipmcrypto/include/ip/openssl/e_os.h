/* e_os.h */
/* Copyright (C) 1995-1998 Eric Young (eay@cryptsoft.com)
 * All rights reserved.
 *
 * This package is an SSL implementation written
 * by Eric Young (eay@cryptsoft.com).
 * The implementation was written so as to conform with Netscapes SSL.
 *
 * This library is free for commercial and non-commercial use as long as
 * the following conditions are aheared to.  The following conditions
 * apply to all code found in this distribution, be it the RC4, RSA,
 * lhash, DES, etc., code; not just the SSL code.  The SSL documentation
 * included with this distribution is covered by the same copyright terms
 * except that the holder is Tim Hudson (tjh@cryptsoft.com).
 *
 * Copyright remains Eric Young's, and as such any Copyright notices in
 * the code are not to be removed.
 * If this package is used in a product, Eric Young should be given attribution
 * as the author of the parts of the library used.
 * This can be in the form of a textual message at program startup or
 * in documentation (online or textual) provided with the package.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    "This product includes cryptographic software written by
 *     Eric Young (eay@cryptsoft.com)"
 *    The word 'cryptographic' can be left out if the rouines from the library
 *    being used are not cryptographic related :-).
 * 4. If you include any Windows specific code (or a derivative thereof) from
 *    the apps directory (application code) you must include an acknowledgement:
 *    "This product includes software written by Tim Hudson (tjh@cryptsoft.com)"
 *
 * THIS SOFTWARE IS PROVIDED BY ERIC YOUNG ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * The licence and distribution terms for any publically available version or
 * derivative of this code cannot be changed.  i.e. this code cannot simply be
 * copied and put under another distribution licence
 * [including the GNU Public Licence.]
 */

#ifndef HEADER_E_OS_H
#define HEADER_E_OS_H

#ifdef IPCRYPTO
#error CANNOT_INCLUDE_BOTH_IPCRYPTO_AND_IPMCRYPTO_IN_THE_SAME_BUILD
#endif

#include "ipcom_config.h"
#define IPCOM_USE_CLIB_PROTO
#include "ipcom_clib.h"
#include <ip/openssl/opensslconf.h>

#include <ip/openssl/e_os2.h>
/* <ip/openssl/e_os2.h> contains what we can justify to make visible
 * to the outside; this file e_os.h is not part of the exported
 * interface. */

#ifdef  __cplusplus
extern "C" {
#endif


/* Used to checking reference counts, most while doing perl5 stuff :-) */
#ifdef REF_PRINT
#undef REF_PRINT
#define REF_PRINT(a,b)	ipcom_fprintf(ip_stderr,"%08X:%4d:%s\n",(int)b,b->references,a)
#endif

#define OPENSSL_SYS_IPCOM

#define OPENSSL_NO_ASM
#define NO_SYS_UN_H
#define NO_SYS_PARAM_H
#define OPENSSL_NO_INLINE_ASM

#if defined(IP_PORT_OSE) && defined(IP_TARGET_WIN32)
#define OPENSSL_NO_LONGLONG
#endif

#ifdef IP_LITTLE_ENDIAN
#  define L_ENDIAN
#elif defined(IP_BIG_ENDIAN)
#  define B_ENDIAN
#else
#  define must_define_IP_XXX_ENDIAN
#endif

#define MS_STATIC	static

#define get_last_sys_error()	errno
#define clear_sys_error()	errno=0

#define get_last_socket_error()	errno
#define clear_socket_error()	errno=0
#define ioctlsocket(a,b,c)	ipcom_socketioctl(a,b,c)
#define closesocket(s)		ipcom_socketclose(s)
#define readsocket(s,b,n)	ipcom_socketread((s),(b),(n))
#define writesocket(s,b,n)	ipcom_socketwrite((s),(b),(n))

#define MS_CALLBACK
#define MS_FAR

#ifdef OPENSSL_NO_STDIO
#  define OPENSSL_NO_FP_API
#endif

#define OPENSSL_CONF	"openssl.cnf"
#define SSLEAY_CONF		OPENSSL_CONF
#define RFILE		".rnd"
#define LIST_SEPARATOR_CHAR ':'
#define NUL_DEV		"/dev/null"
#define EXIT(n)		ipcom_exit(n)

#define SSLeay_getpid()	ipcom_getpid()

/*************/

#ifdef USE_SOCKETS
#  define SSLeay_Read(a,b,c)     ipcom_socketread((a),(b),(c))
#  define SSLeay_Write(a,b,c)    ipcom_socketwrite((a),(b),(c))
#  define SHUTDOWN(fd)    { ipcom_shutdown((fd),0); closesocket((fd)); }
#  define SHUTDOWN2(fd)   { ipcom_shutdown((fd),2); closesocket((fd)); }
#  define INVALID_SOCKET	(-1)
#endif

#ifndef OPENSSL_EXIT
# if defined(MONOLITH) && !defined(OPENSSL_C)
#  define OPENSSL_EXIT(n) return(n)
# else
#  define OPENSSL_EXIT(n) do { EXIT(n); return(n); } while(0)
# endif
#endif

#define Getenv ipcom_getenv

#ifdef  __cplusplus
}
#endif

#endif

