/* ipfreescale.h - implementation of hardware cryptographic support for Freescale SEC 2 processor
*
*/
/*
 ******************************************************************************
 *                     INTERPEAK API HEADER FILE
 *
 *   Document no: @(#) $Name: release6_9_2_binmsp $ $RCSfile: ipfreescale.h,v $ $Revision: 1.23 $
 *   $Source: /home/interpeak/CVSRoot/ipfreescale/include/ipfreescale.h,v $
 *   $Author: markus $ $Date: 2009-06-09 09:07:29 $
 *   $State: Exp $ $Locker:  $
 *
 *   INTERPEAK_COPYRIGHT_STRING
 *   Design and implementation by Markus Carlstedt <markus@interpeak.se>
 ******************************************************************************
 */
#ifndef IPFREESCALE_H
#define IPFREESCALE_H

/*
 ****************************************************************************
 * 1                    DESCRIPTION
 ****************************************************************************
 */
/*
DESCRIPTION
This library provides an implementation of a cryptographic engine for the Freescale SEC 2 processor,
* for use with Wind River Cryptography Libraries.
*/
 /*
 ****************************************************************************
 * 2                    CONFIGURATION
 ****************************************************************************
 */

#include "ipfreescale_config.h"


/*
 ****************************************************************************
 * 3                    INCLUDE FILES
 ****************************************************************************
 */

#include <ipcom_type.h>
#include <ipcom_cstyle.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 ****************************************************************************
 * 4                    DEFINES
 ****************************************************************************
 */

/*
 *===========================================================================
 *                         IPFREESCALE_RELEASE
 *===========================================================================
 * IPFREESCALE release version.
 */
#define IPFREESCALE_RELEASE 60600


/*
 ****************************************************************************
 * 5                    TYPES
 ****************************************************************************
 */

/*
 ****************************************************************************
 * 6                    FUNCTIONS
 ****************************************************************************
 */

/* MD5 digest functions */
/*******************************************************************************
*
* ipfreescale_md5_digest - Calculate message digest using the MD5 algorithm.
*
* This routine calculates a message digest using the MD5 algorithm.
*
* Parameters:
* \is
* \i <data>
* Pointer to buffer with the data to hash.
*
* \i <length>
* Length of data in bytes.
*
* \i <digest>
* Pointer to buffer for the digest (16 bytes).
* \ie
*
* RETURNS: -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_md5_digest
    (
    Ip_u8 *data,
    Ip_u32 length,
    Ip_u8 *digest
    );

/*******************************************************************************
*
* ipfreescale_md5_hmac - Calculate HMAC using the MD5 algorithm.
*
* This routine calculates a HMAC using the MD5 algorithm.
*
* Parameters:
* \is
* \i <data>
* Pointer to buffer with the data to hash.
*
* \i <length>
* Length of data in bytes.
*
* \i <key>
* Pointer to buffer with the key.
*
* \i <keylength>
* Length of key in bytes.
*
* \i <hmac>
* Pointer to buffer for the hmac (16 bytes).
* \ie
*
* RETURNS: -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_md5_hmac
    (
    Ip_u8 *data,
    Ip_u32 length,
    Ip_u8 *key,
    Ip_u32 keylength,
    Ip_u8 *hmac
    );

/*******************************************************************************
*
* ipfreescale_md5_digest_init - initialize MD5 message digest context
*
* This routine initializes an MD5 message context.
*
* Parameters:
* \is
* \i <ctx>
* Pointer to the context.
* \ie
*
* RETURNS: 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_md5_digest_init
    (
    void *ctx
    );

/*******************************************************************************
*
* ipfreescale_md5_digest_update - update MD5 message digest context
*
* This routine updates an MD5 message context.
*
* Parameters:
* \is
* \i <ctx>
* Pointer to the context.
*
* \i <data>
* Pointer to buffer with the data to hash.
*
* \i <length>
* Length of data in bytes.
* \ie
*
* RETURNS: -1 = error, 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_md5_digest_update
    (
    void *ctx,
    IP_CONST Ip_u8 *data,
    Ip_u32 length
    );

/*******************************************************************************
*
* ipfreescale_md5_digest_final - finalize MD5 message digest context
*
* This routine finalizes an MD5 message digest context.
*
* Parameters:
* \is
* \i <ctx>
* Pointer to the context.
*
* \i <digest>
* Pointer to buffer for the digest (16 bytes).
* \ie
*
* RETURNS: -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_md5_digest_final
    (
    void *ctx,
    Ip_u8 *digest
    );

/* SHA1 digest functions */
/*******************************************************************************
*
* ipfreescale_sha1_digest - calculate message digest using the SHA1 algorithm
*
* This routine calculates a message digest using the SHA1 algorithm.
*
* Parameters:
* \is
* \i <data>
* Pointer to buffer with the data to hash.
*
* \i <length>
* Length of data in bytes.
*
* \i <digest>
* Pointer to buffer for the digest (20 bytes).
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_sha1_digest
    (
    Ip_u8 *data,
    Ip_u32 length,
    Ip_u8 *digest
    );


/*******************************************************************************
*
* ipfreescale_sha1_hmac - Calculate HMAC using the SHA1 algorithm.
*
* This routine calculates a HMAC using the SHA1 algorithm.
*
* Parameters:
* \is
* \i <data>
* Pointer to buffer with the data to hash.
*
* \i <length>
* Length of data in bytes.
*
* \i <key>
* Pointer to buffer with the key.
*
* \i <keylength>
* Length of key in bytes.
*
* \i <hmac>
* Pointer to buffer for the hmac (20 bytes).
* \ie
*
* RETURNS: -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_sha1_hmac
    (
    Ip_u8 *data,
    Ip_u32 length,
    Ip_u8 *key,
    Ip_u32 keylength,
    Ip_u8 *hmac
    );


/*******************************************************************************
*
* ipfreescale_sha1_digest_init - initialize SHA1 message digest context
*
* This routine initializes a SHA1 message digest context.
*
* Parameters:
* \is
* \i <ctx>
* Pointer to the context.
* \ie
*
* RETURNS:
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_sha1_digest_init
    (
    void *ctx
    );

/*******************************************************************************
*
* ipfreescale_sha1_digest_update - update SHA1 message digest context
*
* This routine updates a SHA1 message digest context.
*
* Parameters:
* \is
* \i <ctx>
* Pointer to the context.
*
* \i <data>
* Pointer to buffer with the data to hash.
*
* \i <length>
* Length of data in bytes.
* \ie
*
* RETURNS:
* -1 = error, 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_sha1_digest_update
    (
    void *ctx,
    IP_CONST Ip_u8 *data,
    Ip_u32 length
    );

/*******************************************************************************
*
* ipfreescale_sha1_digest_final - Finalize SHA1 message digest context
*
* This routine finalizes a SHA1 message digest context.
*
* Parameters:
* \is
* \i <ctx>
* Pointer to the context.
*
* \i <digest>
* Pointer to buffer for the digest (20 bytes).
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_sha1_digest_final
    (
    void *ctx,
    Ip_u8 *digest
    );

/*******************************************************************************
*
* ipfreescale_digest_copy - copy message digest context
*
* This routine copies a message digest context.
*
* Parameters:
* \is
* \i <ctx_to>
* Pointer to the destination context.
*
* \i <ctx_from>
* Pointer to the source context.
* \ie
*
* RETURNS:
* -1 = error, 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_digest_copy
    (
    void *ctx_to,
    IP_CONST void *ctx_from
    );

/*******************************************************************************
*
* ipfreescale_digest_cleanup - clean up message digest context
*
* This routine cleans up a message digest context.
*
* Parameters:
* \is
* \i <ctx>
* Pointer to the context.
* \ie
*
* RETURNS:
* 1= ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_digest_cleanup
    (
    void *ctx
    );

/*******************************************************************************
*
* ipfreescale_des_cbc_cipher - encrypt or decrypt using DES-CBC cipher
*
* This routine encrypts or decrypts a data buffer using the DES-CBC cipher.
*
* Parameters:
* \is
* \i <out>
* Pointer to the result.
*
* \i <in>
* Pointer to buffer with the data to encrypt/decrypt.
*
* \i <length>
* Length of data in bytes.
*
* \i <key>
* Pointer to buffer with the key (8 bytes).
*
* \i <iv>
* Initialization vector (8 bytes). Updated by hardware.
*
* \i <enc>
* 1 = encryption. 0 = decryption.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_des_cbc_cipher
    (
    Ip_u8 *out,
    IP_CONST Ip_u8 *in,
    Ip_u32 length,
    void *key,
    Ip_u8 *iv,
    int enc
    );

/*******************************************************************************
*
* ipfreescale_des_ecb_cipher - encrypt or decrypt using DES-ECB cipher
*
* This routine encrypts or decrypts a data buffer using the DES-ECB cipher.
*
* Parameters:
* \is
* \i <out>
* Pointer to the result.
*
* \i <in>
* Pointer to buffer with the data to encrypt/decrypt.
*
* \i <length>
* Length of data in bytes.
*
* \i <key>
* Pointer to buffer with the key (8 bytes).
*
* \i <enc>
* 1 = encryption. 0 = decryption.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_des_ecb_cipher
    (
    Ip_u8 *out,
    IP_CONST Ip_u8 *in,
    Ip_u32 length,
    void *key,
    int enc
    );

/*******************************************************************************
*
* ipfreescale_3des_cbc_cipher - encrypt or decrypt using 3DES-CBC cipher
*
* This routine encrypts or decrypts a data buffer using the 3DES-CBC cipher.
*
* Parameters:
* \is
* \i <out>
* Pointer to the result.
*
* \i <in>
* Pointer to buffer with the data to encrypt/decrypt.
*
* \i <length>
* Length of data in bytes.
*
* \i <key>
* Pointer to buffer with the key (24 bytes).
*
* \i <iv>
* Initialization vector (8 bytes). Updated by hardware.
*
* \i <enc>
* 1 = encryption. 0 = decryption.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_3des_cbc_cipher
    (
    Ip_u8 *out,
    IP_CONST Ip_u8 *in,
    Ip_u32 length,
    void *key,
    Ip_u8 *iv,
    int enc
    );

/*******************************************************************************
*
* ipfreescale_3des_ecb_cipher - encrypt or decrypt using 3DES-ECB cipher
*
* This routine encrypts or decrypts a data buffer using the 3DES-ECB cipher.
*
* Parameters:
* \is
* \i <out>
* Pointer to the result.
*
* \i <in>
* Pointer to buffer with the data to encrypt/decrypt.
*
* \i <length>
* Length of data in bytes.
*
* \i <key>
* Pointer to buffer with the key (24 bytes).
*
* \i <enc>
* 1 = encryption. 0 = decryption.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_3des_ecb_cipher
    (
    Ip_u8 *out,
    IP_CONST Ip_u8 *in,
    Ip_u32 length,
    void *key,
    int enc
    );

/*******************************************************************************
*
* ipfreescale_aes128_cbc_cipher - encrypt or decrypt using the AES-CBC-128 cipher
*
* This routine encrypts or decrypts a data buffer using the AES-CBC-128 cipher.
*
* Parameters:
* \is
* \i <out>
* Pointer to the result.
*
* \i <in>
* Pointer to buffer with the data to encrypt/decrypt.
*
* \i <length>
* Length of data in bytes.
*
* \i <key>
* Pointer to buffer with the key (16 bytes).
*
* \i <iv>
* Initialization vector (16 bytes). Updated by hardware.
*
* \i <enc>
* 1 = encryption. 0 = decryption.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_aes128_cbc_cipher
    (
    Ip_u8 *out,
    IP_CONST Ip_u8 *in,
    Ip_u32 length,
    void *key,
    Ip_u8 *iv,
    int enc
    );

/*******************************************************************************
*
* ipfreescale_aes128_ecb_cipher - encrypt or decrypt using the AES-ECB-128 cipher
*
* This routine encrypts or decrypts a data buffer using the AES-ECB-128 cipher.
*
* Parameters:
* \is
* \i <out>
* Pointer to the result.
*
* \i <in>
* Pointer to buffer with the data to encrypt/decrypt.
*
* \i <length>
* Length of data in bytes.
*
* \i <key>
* Pointer to buffer with the key (16 bytes).
*
* \i <enc>
* 1 = encryption. 0 = decryption.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_aes128_ecb_cipher
    (
    Ip_u8 *out,
    IP_CONST Ip_u8 *in,
    Ip_u32 length,
    void *key,
    int enc
    );

/*******************************************************************************
*
* ipfreescale_aes192_cbc_cipher - encrypt or decrypt using the AES-CBC-192 cipher
*
* This routine encrypts or decrypts a data buffer using the AES-CBC-192 cipher.
*
* Parameters:
* \is
* \i <out>
* Pointer to the result.
*
* \i <in>
* Pointer to buffer with the data to encrypt/decrypt.
*
* \i <length>
* Length of data in bytes.
*
* \i <key>
* Pointer to buffer with the key (24 bytes).
*
* \i <iv>
* Initialization vector (24 bytes). Updated by hardware.
*
* \i <enc>
* 1 = encryption. 0 = decryption.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_aes192_cbc_cipher
    (
    Ip_u8 *out,
    IP_CONST Ip_u8 *in,
    Ip_u32 length,
    void *key,
    Ip_u8 *iv,
    int enc
    );

/*******************************************************************************
*
* ipfreescale_aes192_ecb_cipher - encrypt or decrypt using the AES-ECB-192 cipher
*
* This routine encrypts or decrypts a data buffer using the AES-ECB-192 cipher.
*
* Parameters:
* \is
* \i <out>
* Pointer to the result.
*
* \i <in>
* Pointer to buffer with the data to encrypt/decrypt.
*
* \i <length>
* Length of data in bytes.
*
* \i <key>
* Pointer to buffer with the key (24 bytes).
*
* \i <enc>
* 1 = encryption. 0 = decryption.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_aes192_ecb_cipher
    (
    Ip_u8 *out,
    IP_CONST Ip_u8 *in,
    Ip_u32 length,
    void *key,
    int enc
    );

/*******************************************************************************
*
* ipfreescale_aes256_cbc_cipher - encrypt or decrypt using the AES-CBC-256 cipher
*
* This routine encrypts or decrypts a data buffer using the AES-CBC-256 cipher.
*
* Parameters:
* \is
* \i <out>
* Pointer to the result.
*
* \i <in>
* Pointer to buffer with the data to encrypt/decrypt.
*
* \i <length>
* Length of data in bytes.
*
* \i <key>
* Pointer to buffer with the key (32 bytes).
*
* \i <iv>
* Initialization vector (32 bytes). Updated by hardware.
*
* \i <enc>
* 1 = encryption. 0 = decryption.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_aes256_cbc_cipher
    (
    Ip_u8 *out,
    IP_CONST Ip_u8 *in,
    Ip_u32 length,
    void *key,
    Ip_u8 *iv,
    int enc
    );

/*******************************************************************************
*
* ipfreescale_aes256_ecb_cipher - encrypt or decrypt using the AES-ECB-256 cipher
*
* This routine encrypts or decrypts a data buffer using the AES-ECB-256 cipher.
*
* Parameters:
* \is
* \i <out>
* Pointer to the result.
*
* \i <in>
* Pointer to buffer with the data to encrypt/decrypt.
*
* \i <length>
* Length of data in bytes.
*
* \i <key>
* Pointer to buffer with the key (32 bytes).
*
* \i <enc>
* 1 = encryption. 0 = decryption.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_aes256_ecb_cipher
    (
    Ip_u8 *out,
    IP_CONST Ip_u8 *in,
    Ip_u32 length,
    void *key,
    int enc
    );

/*******************************************************************************
*
* ipfreescale_rc4_cipher - RC4 stream cipher
*
* This routine performs an RC4 stream cipher.
* Provide key and output context for operation with key load and context save.
* Provide input context and output context for operation with context load and context save.
*
* Parameters:
* \is
* \i <out>
* Pointer to the result.
*
* \i <in>
* Pointer to buffer with the data to encrypt/decrypt.
*
* \i <length>
* Length of data in bytes.
*
* \i <key>
* Pointer to buffer with the key.
*
* \i <keylen>
* Length of encryption key (1-16 bytes).
*
* \i <ctxi>
* Buffer with input context (259 bytes).
*
* \i <ctxo>
* Buffer with output context (259 bytes).
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_rc4_cipher
    (
    Ip_u8 *out,
    IP_CONST Ip_u8 *in,
    Ip_u32 length,
    void *key,
    Ip_u32 keylen,
    Ip_u8 *ctxi,
    Ip_u8 *ctxo
    );

/*******************************************************************************
*
* ipfreescale_mod_exp - modular exponentiation
*
* This routine performs modular exponentiation. Calculates b^e mod m. The size of
* the base and exponent buffers are assumed to be of equal size as the modulus
* length and zero padded with leading zeros if necessary. The size of the result buffer
* is also equal to the modulus length and the result will be zero padded if necessary.
*
* Parameters:
* \is
* \i <out>
* Pointer to the result.
*
* \i <base>
* Pointer to buffer with the base.
*
* \i <e>
* Pointer to buffer with the exponent.
*
* \i <mod>
* Pointer to buffer with the result.
*
* \i <modlen>
* Length of modulus.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_mod_exp
    (
    Ip_u8 *out,
    IP_CONST Ip_u8 *base,
    IP_CONST Ip_u8 *e,
    IP_CONST Ip_u8 *mod,
    Ip_u32 modlen
    );

/*******************************************************************************
*
* ipfreescale_random_gen - generate sequence of random data
*
* This routine generates a sequence of random data.
*
* Parameters:
* \is
* \i <data>
* Pointer to buffer for the generated random data.
*
* \i <length>
* Number of bytes in the sequence.
* \ie
*
* RETURNS: -1 = error,
* 0 = timeout,
* 1 = ok
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_random_gen
    (
    Ip_u8 *data,
    Ip_u32 length
    );


/* IPSEC ESP functions */
#ifdef IPIPSEC2
IP_PUBLIC int ipfreescale_ipsec_esp_null_md5_input(Ip_u8 *data,
                                                      Ip_u32 length,
                                                      Iphwcrypto_esp_cbc_sa *sa,
                                                      Ip_u8 *digest,
                                                      Ipipsec_param *param,
                                                      Ipcom_pkt *pkt);

IP_PUBLIC int ipfreescale_ipsec_esp_null_md5_output(Ip_u8 *data,
                                                       Ip_u32 length,
                                                       Iphwcrypto_esp_cbc_sa *sa,
                                                       Ip_u8 *digest,
                                                       Ipipsec_param *param,
                                                       Ipcom_pkt *pkt);

IP_PUBLIC int ipfreescale_ipsec_esp_null_sha1_input(Ip_u8 *data,
                                                      Ip_u32 length,
                                                      Iphwcrypto_esp_cbc_sa *sa,
                                                      Ip_u8 *digest,
                                                      Ipipsec_param *param,
                                                      Ipcom_pkt *pkt);

IP_PUBLIC int ipfreescale_ipsec_esp_null_sha1_output(Ip_u8 *data,
                                                       Ip_u32 length,
                                                       Iphwcrypto_esp_cbc_sa *sa,
                                                       Ip_u8 *digest,
                                                       Ipipsec_param *param,
                                                       Ipcom_pkt *pkt);

IP_PUBLIC int ipfreescale_ipsec_esp_des_cbc_null_input(Ip_u8 *data,
                                                      Ip_u32 length,
                                                      Iphwcrypto_esp_cbc_sa *sa,
                                                      Ip_u8 *digest,
                                                      Ipipsec_param *param,
                                                      Ipcom_pkt *pkt);

IP_PUBLIC int ipfreescale_ipsec_esp_des_cbc_null_output(Ip_u8 *data,
                                                       Ip_u32 length,
                                                       Iphwcrypto_esp_cbc_sa *sa,
                                                       Ip_u8 *digest,
                                                       Ipipsec_param *param,
                                                       Ipcom_pkt *pkt);

/*******************************************************************************
*
* ipfreescale_ipsec_esp_des_cbc_md5_input - IPsec ESP input processing using DES-CBC-MD5
*
* This routine performs IPsec ESP input processing using DES-CBC-MD5.
*
* Parameters:
* \is
* \i <data>
* Pointer to the packet data.
*
* \i <length>
* Length of the packet.
*
* \i <sa>
* Pointer to the sa (Security Association).
*
* \i <digest>
* Pointer to the message authentication code.
*
* \i <param>
* Pointer to IPsec Parameters
*
* \i <pkt>
* Pointer to the packet structure.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok,
* 2 = kept
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_ipsec_esp_des_cbc_md5_input
    (
    Ip_u8 *data,
    Ip_u32 length,
    Iphwcrypto_esp_cbc_sa *sa,
    Ip_u8 *digest,
    Ipipsec_param *param,
    Ipcom_pkt *pkt
    );

/*******************************************************************************
*
* ipfreescale_ipsec_esp_des_cbc_md5_output - IPsec ESP output processing using DES-CBC-MD5
*
* This routine performs IPsec ESP output processing using DES-CBC-MD5.
*
* Parameters:
* \is
* \i <data>
* Pointer to the packet data.
*
* \i <length>
* Length of the packet.
*
* \i <sa>
* Pointer to the sa (Security Association).
*
* \i <digest>
* Pointer to the message authentication code.
*
* \i <param>
* Pointer to IPsec Parameters
*
* \i <pkt>
* Pointer to the packet structure.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok,
* 2 = kept
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_ipsec_esp_des_cbc_md5_output
    (
    Ip_u8 *data,
    Ip_u32 length,
    Iphwcrypto_esp_cbc_sa *sa,
    Ip_u8 *digest,
    Ipipsec_param *param,
    Ipcom_pkt *pkt
    );

/*******************************************************************************
*
* ipfreescale_ipsec_esp_des_cbc_sha1_input - IPsec ESP input processing using DES-CBC-SHA1
*
* This routine performs input processing using DES-CBC-SHA1.
*
* Parameters:
* \is
* \i <data>
* Pointer to the packet data.
*
* \i <length>
* Length of the packet.
*
* \i <sa>
* Pointer to the sa (Security Association).
*
* \i <digest>
* Pointer to the message authentication code.
*
* \i <param>
* Pointer to IPsec Parameters
*
* \i <pkt>
* Pointer to the packet structure.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok,
* 2 = kept
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_ipsec_esp_des_cbc_sha1_input
    (
    Ip_u8 *data,
    Ip_u32 length,
    Iphwcrypto_esp_cbc_sa *sa,
    Ip_u8 *digest,
    Ipipsec_param *param,
    Ipcom_pkt *pkt
    );

/*******************************************************************************
*
* ipfreescale_ipsec_esp_des_cbc_sha1_output - IPsec ESP output processing using DES-CBC-SHA1
*
* This routine performs IPsec ESP output processing using DES-CBC-SHA1.
*
* Parameters:
* \is
* \i <data>
* Pointer to the packet data.
*
* \i <length>
* Length of the packet.
*
* \i <sa>
* Pointer to the sa (Security Association).
*
* \i <digest>
* Pointer to the message authentication code.
*
* \i <param>
* Pointer to IPsec Parameters
*
* \i <pkt>
* Pointer to the packet structure.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok,
* 2= kept
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_ipsec_esp_des_cbc_sha1_output
    (
    Ip_u8 *data,
    Ip_u32 length,
    Iphwcrypto_esp_cbc_sa *sa,
    Ip_u8 *digest,
    Ipipsec_param *param,
    Ipcom_pkt *pkt
    );

IP_PUBLIC int ipfreescale_ipsec_esp_3des_cbc_null_input(Ip_u8 *data,
                                                      Ip_u32 length,
                                                      Iphwcrypto_esp_cbc_sa *sa,
                                                      Ip_u8 *digest,
                                                      Ipipsec_param *param,
                                                      Ipcom_pkt *pkt);

IP_PUBLIC int ipfreescale_ipsec_esp_3des_cbc_null_output(Ip_u8 *data,
                                                       Ip_u32 length,
                                                       Iphwcrypto_esp_cbc_sa *sa,
                                                       Ip_u8 *digest,
                                                       Ipipsec_param *param,
                                                       Ipcom_pkt *pkt);

/*******************************************************************************
*
* ipfreescale_ipsec_esp_3des_cbc_md5_input - IPsec ESP input processing using 3DES-CBC-MD5
*
* This routine performs IPsec ESP input processing using 3DES-CBC-MD5.
*
* Parameters:
* \is
* \i <data>
* Pointer to the packet data.
*
* \i <length>
* Length of the packet.
*
* \i <sa>
* Pointer to the sa (Security Association).
*
* \i <digest>
* Pointer to the message authentication code.
*
* \i <param>
* Pointer to IPsec Parameters
*
* \i <pkt>
* Pointer to the packet structure.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok,
* 2 = kept
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_ipsec_esp_3des_cbc_md5_input
    (
    Ip_u8 *data,
    Ip_u32 length,
    Iphwcrypto_esp_cbc_sa *sa,
    Ip_u8 *digest,
    Ipipsec_param *param,
    Ipcom_pkt *pkt
    );

/*******************************************************************************
*
* ipfreescale_ipsec_esp_3des_cbc_md5_output - IPsec ESP output processing using 3DES-CBC-MD5
*
* This routine performs IPsec ESP output processing using 3DES-CBC-MD5.
*
* Parameters:
* \is
* \i <data>
* Pointer to the packet data.
*
* \i <length>
* Length of the packet.
*
* \i <sa>
* Pointer to the sa (Security Association).
*
* \i <digest>
* Pointer to the message authentication code.
*
* \i <param>
* Pointer to IPsec Parameters
*
* \i <pkt>
* Pointer to the packet structure.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok,
* 2 = kept
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_ipsec_esp_3des_cbc_md5_output
    (
    Ip_u8 *data,
    Ip_u32 length,
    Iphwcrypto_esp_cbc_sa *sa,
    Ip_u8 *digest,
    Ipipsec_param *param,
    Ipcom_pkt *pkt
    );

/*******************************************************************************
*
* ipfreescale_ipsec_esp_3des_cbc_sha1_input - IPsec ESP input processing using 3DES-CBC-SHA1
*
* This routine performs IPsec ESP input processing using 3DES-CBC-SHA1.
*
* Parameters:
* \is
* \i <data>
* Pointer to the packet data.
*
* \i <length>
* Length of the packet.
*
* \i <sa>
* Pointer to the sa (Security Association).
*
* \i <digest>
* Pointer to the message authentication code.
*
* \i <param>
* Pointer to IPsec Parameters
*
* \i <pkt>
* Pointer to the packet structure.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok,
* 2 = kept
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_ipsec_esp_3des_cbc_sha1_input
    (
    Ip_u8 *data,
    Ip_u32 length,
    Iphwcrypto_esp_cbc_sa *sa,
    Ip_u8 *digest,
    Ipipsec_param *param,
    Ipcom_pkt *pkt
    );

/*******************************************************************************
*
* ipfreescale_ipsec_esp_3des_cbc_sha1_output - IPsec ESP output processing using 3DES-CBC-SHA1
*
* This routine performs IPsec ESP output processing using 3DES-CBC-SHA1.
*
* Parameters:
* \is
* \i <data>
* Pointer to the packet data.
*
* \i <length>
* Length of the packet.
*
* \i <sa>
* Pointer to the sa (Security Association).
*
* \i <digest>
* Pointer to the message authentication code.
*
* \i <param>
* Pointer to IPsec Parameters
*
* \i <pkt>
* Pointer to the packet structure.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok,
* 2 = kept
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_ipsec_esp_3des_cbc_sha1_output
    (
    Ip_u8 *data,
    Ip_u32 length,
    Iphwcrypto_esp_cbc_sa *sa,
    Ip_u8 *digest,
    Ipipsec_param *param,
    Ipcom_pkt *pkt
    );


IP_PUBLIC int ipfreescale_ipsec_esp_aes_cbc_null_input(Ip_u8 *data,
                                                      Ip_u32 length,
                                                      Iphwcrypto_esp_cbc_sa *sa,
                                                      Ip_u8 *digest,
                                                      Ipipsec_param *param,
                                                      Ipcom_pkt *pkt);

IP_PUBLIC int ipfreescale_ipsec_esp_aes_cbc_null_output(Ip_u8 *data,
                                                       Ip_u32 length,
                                                       Iphwcrypto_esp_cbc_sa *sa,
                                                       Ip_u8 *digest,
                                                       Ipipsec_param *param,
                                                       Ipcom_pkt *pkt);

/*******************************************************************************
*
* ipfreescale_ipsec_esp_aes_cbc_md5_input - IPsec ESP input processing using AES-CBC-MD5
*
* This routine performs IPsec ESP input processing using AES-CBC-MD5.
*
* Parameters:
* \is
* \i <data>
* Pointer to the packet data.
*
* \i <length>
* Length of the packet.
*
* \i <sa>
* Pointer to the sa (Security Association).
*
* \i <digest>
* Pointer to the message authentication code.
*
* \i <param>
* Pointer to IPsec Parameters
*
* \i <pkt>
* Pointer to the packet structure.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok,
* 2 = kept
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_ipsec_esp_aes_cbc_md5_input
    (
    Ip_u8 *data,
    Ip_u32 length,
    Iphwcrypto_esp_cbc_sa *sa,
    Ip_u8 *digest,
    Ipipsec_param *param,
    Ipcom_pkt *pkt
    );

/*******************************************************************************
*
* ipfreescale_ipsec_esp_aes_cbc_md5_output - IPsec ESP output processing using AES-CBC-MD5
*
* This routine performs IPsec ESP output processing using AES-CBC-MD5.
*
* Parameters:
* \is
* \i <data>
* Pointer to the packet data.
*
* \i <length>
* Length of the packet.
*
* \i <sa>
* Pointer to the sa (Security Association).
*
* \i <digest>
* Pointer to the message authentication code.
*
* \i <param>
* Pointer to IPsec Parameters
*
* \i <pkt>
* Pointer to the packet structure.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok,
* 2 = kept
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_ipsec_esp_aes_cbc_md5_output
    (
    Ip_u8 *data,
    Ip_u32 length,
    Iphwcrypto_esp_cbc_sa *sa,
    Ip_u8 *digest,
    Ipipsec_param *param,
    Ipcom_pkt *pkt
    );

/*******************************************************************************
*
* ipfreescale_ipsec_esp_aes_cbc_sha1_input - IPsec ESP input processing using AES-CBC-SHA1
*
* This routine performs IPsec ESP input processing using AES-CBC-SHA1.
*
* Parameters:
* \is
* \i <data>
* Pointer to the packet data.
*
* \i <length>
* Length of the packet.
*
* \i <sa>
* Pointer to the sa (Security Association).
*
* \i <digest>
* Pointer to the message authentication code.
*
* \i <param>
* Pointer to IPsec Parameters
*
* \i <pkt>
* Pointer to the packet structure.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok,
* 2 = kept
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_ipsec_esp_aes_cbc_sha1_input
    (
    Ip_u8 *data,
    Ip_u32 length,
    Iphwcrypto_esp_cbc_sa *sa,
    Ip_u8 *digest,
    Ipipsec_param *param,
    Ipcom_pkt *pkt
    );

/*******************************************************************************
*
* ipfreescale_ipsec_esp_aes_cbc_sha1_output - IPsec ESP output processing using AES-CBC-SHA1
*
* This routine performs IPsec ESP output processing using AES-CBC-SHA1.
*
* Parameters:
* \is
* \i <data>
* Pointer to the packet data.
*
* \i <length>
* Length of the packet.
*
* \i <sa>
* Pointer to the sa (Security Association).
*
* \i <digest>
* Pointer to the message authentication code.
*
* \i <param>
* Pointer to IPsec Parameters
*
* \i <pkt>
* Pointer to the packet structure.
* \ie
*
* RETURNS:
* -1 = error, 0 = timeout,
* 1 = ok,
* 2 = kept
*
* ERRNO
* \&N/A
*
*/
IP_PUBLIC int ipfreescale_ipsec_esp_aes_cbc_sha1_output
    (
    Ip_u8 *data,
    Ip_u32 length,
    Iphwcrypto_esp_cbc_sa *sa,
    Ip_u8 *digest,
    Ipipsec_param *param,
    Ipcom_pkt *pkt
    );

#endif  /* #ifdef IPIPSEC2 */


#ifdef __cplusplus
}
#endif

#endif

/*
 ****************************************************************************
 *                      END OF FILE
 ****************************************************************************
 */
