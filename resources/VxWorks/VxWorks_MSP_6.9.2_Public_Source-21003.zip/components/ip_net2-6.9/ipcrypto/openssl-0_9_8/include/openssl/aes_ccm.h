/* crypto/aes/aes_ccm.h */
/*----------------------------------------------------------------------------
// Licensed materials - Property of IBM                                      
//
// (C) Copyright IBM Corp.  2007
// This code was donated to the OpenSSL project under the terms of the 
// OpenSSL license.
//
//---------------------------------------------------------------------------*/

