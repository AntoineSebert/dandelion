#if !defined(DEMO_CODE)
/*****************************************************************************
// IBM Confidential
// OCO Source Materials
// ICC
// (C) Copyright IBM Corp.  2003,2007
// The source code for this program is not published or otherwise
// divested of its trade secrets, irrespective of what has been
// deposited with the U.S. Copyright Office.
//
// File, Component, Release:
//
// icc_test/hex_utils.h, ICC_TEST, icc_8.0, icc8.0_070119
//
// Version: 1.5
//
// Date and Time File was last checked in:       07/06/06 18:34:08
// Date and Time File was extracted/checked out: 07/08/19 20:01:27
//
// Description: Common utilities for hexadecimal conversion.
//
// Authors  Defect (D) or Feature (F) and Number
// -------  ------------------------------------
// PTW      D39582  Add copyright notices
// PTW      D39650  Add logical operators on hex strings
// PTW      D39919  Refactor hex manipulation routines
//
*******************************************************************************/
#endif

#if !defined(HEX_UTILS_H)
#define HEX_UTILS_H

#if !defined(EVP_MAX_IV_LENGTH)
#define EVP_MAX_IV_LENGTH 16
#endif

#if defined(__OS2__)
#include <io.h>
#endif

#ifdef  __cplusplus
extern "C" {
#endif

  unsigned char * read_rawhex(int in, int *len); /* in is an fd */
  int write_rawhex(int out,unsigned char *buffer, int len); /* out is an fd */
  int x2bin(char c);
  void bin2x(unsigned char in,unsigned char out[2]);
  int Bin2HexBuffer(char *in, int inlen, char **out);
  int Hex2BinBuffer(char *in, int inlen, char **out);
  
  void write_iv(int dumpFile,int ekeylen,char *ekey,char *iv);
  void read_iv(int dumpFile,int *keylen,char *ekey,char *iv);

  /*! @brief  return a ^ b on the numbers represented in hexadecimal in a and b.
     if result is NULL, we allocate storage.
  */   
  unsigned char *xor_hex(unsigned char *result,unsigned char *a, unsigned char *b);

  /*! @brief  return a & b on the numbers represented in hexadecimal in a and b.
     if result is NULL, we allocate storage.
  */   
  unsigned char *and_hex(unsigned char *result,unsigned char *a,unsigned char *b);

  /*! @brief  return a | b on the numbers represented in hexadecimal in a and b.
     if result is NULL, we allocate storage.
  */   
  unsigned char *or_hex(unsigned char *result,unsigned char *a,unsigned char *b);

/* Higher level hex manipulation routines */

/* Simple hack to get something type-readable */
#define HEXSTRING char *
#define BINSTRING char *


HEXSTRING binstr_to_hexstr(BINSTRING b);
BINSTRING get_binstr_frombuffer(unsigned char *buf,int len);
int getblen(HEXSTRING data);
int getbinlen(BINSTRING data);
HEXSTRING get_hexstr_frombuffer(unsigned char *b,int len);
unsigned char * setbuffer_from_hexstr(unsigned char *b,HEXSTRING s);
unsigned char * setbuffer_from_binstr(unsigned char *b,BINSTRING s);

#ifdef  __cplusplus
}
#endif

#endif
