/* ipdiameter_tls.h - IPNet Diameter TLS head file */

/*
 * Copyright (c) 2007 Wind River Systems, Inc.
 *
 * The right to copy, distribute or otherwise make use of this software
 * may be licensed only pursuant to the terms of an applicable Wind River
 * license agreement. No license to Wind River intellectual property rights
 * is granted herein. All rights not licensed by Wind River are reserved
 * by Wind River.
 */

/*
modification history
--------------------
01b,10oct07,tlu  Port to Linux
01a,08aug07,tlu  Created.
*/

#ifndef IPDIAMETER_TLS_H
#define IPDIAMETER_TLS_H


#ifdef IPSSL
/*
 ****************************************************************************
 *                     INCLUDE FILES
 ****************************************************************************
 */

#include <ipcom_tags.h>
#include <ipcom_type.h>
#include <openssl/rand.h>
#include <openssl/err.h>

#include <ipdiameter_config.h>
#include <ipdiameter_constant.h>
#include <ipdiameter_peer.h>



/*
 ****************************************************************************
 *                     DEFINES
 ****************************************************************************
 */


#define DIAMETER_CIPHER_LIST "ALL:!ADH:!LOW:!EXP:@STRENGTH"



/*
 ****************************************************************************
 *                     TYPES
 ****************************************************************************
 */



/*
 ****************************************************************************
 *                      GLOBAL FUNCTIONS
 ****************************************************************************
 */

IP_PUBLIC Ip_err ipdiameter_setup_ssl_ctx();
IP_PUBLIC Ip_err ipdiameter_tls_connection(Ipdiameter_peer_entry *peer, 
		Ip_bool connect);
IP_PUBLIC int ipdiameter_tls_read(Ipdiameter_peer_entry *peer, char *buf, 
		int length);
IP_PUBLIC int ipdiameter_tls_write(SSL *ssl, char *buf, int length);


#endif  /* IPSSL */


#endif   /* #ifndef IPDIAMETER_TLS_H */


/*
 ****************************************************************************
 *                      END OF FILE
 ****************************************************************************
 */

